#include <stdio.h>
#include <unistd.h>

int main(int argc, char** argv)
{
  int i;

    i = -1;

    printf( "hello world %d\n", i );

  return 0;
}
