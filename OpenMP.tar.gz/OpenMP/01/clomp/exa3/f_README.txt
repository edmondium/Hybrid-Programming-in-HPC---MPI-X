FILES
f_ex3.f

FUNCTION
A simple matrix multiplication

EXPECTED OUTPUT
    iter            1
      
    array          116         134         152           8           2
    -4

    iter            2

    array          116         134         152           8           2
    -4

    iter            3

    array          116         134         152           8           2
    -4

