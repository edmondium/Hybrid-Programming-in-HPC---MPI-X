#!/bin/bash

#PBS -N co-co_c
#PBS -l select=1:node_type=rome:mpiprocs=128
#PBS -l walltime=00:02:00
 
cd $PBS_O_WORKDIR

  export MPI_PROCESSES=4
  export OMP_NUM_THREADS=4

  echo '##########################################'
  echo '# co-co = Demo for CONDITIONAL COMPILATION'
  echo '#         MPI_PROCESSES='$MPI_PROCESSES
  echo '#         OMP_NUM_THREADS='$OMP_NUM_THREADS
  echo '##########################################'
  echo '### CHECK COMPILER VERSION: ##############'
  echo 'mpicc --version'
        mpicc --version
  echo 'gcc --version'
        gcc --version
  echo '### MPI+OpenMP: ##########################'
  echo 'mpicc -DUSE_MPI -fopenmp -o co-co co-co.c'
        mpicc -DUSE_MPI -fopenmp -o co-co co-co.c
  echo 'mpirun -n $MPI_PROCESSES ./co-co | sort -n'
        mpirun -n $MPI_PROCESSES ./co-co | sort -n
  echo '### MPI: #################################'
  echo 'mpicc -DUSE_MPI -o co-co co-co.c'
        mpicc -DUSE_MPI -o co-co co-co.c
  echo 'mpirun -n $MPI_PROCESSES ./co-co | sort -n'
        mpirun -n $MPI_PROCESSES ./co-co | sort -n
  echo '### OpenMP: ##############################'
  echo 'gcc -fopenmp -o co-co co-co.c'
        gcc -fopenmp -o co-co co-co.c
  echo './co-co | sort -n'
        ./co-co | sort -n
  echo '### serial: ##############################'
  echo 'gcc -o co-co co-co.c'
        gcc -o co-co co-co.c
  echo './co-co | sort -n'
        ./co-co | sort -n
  echo '##########################################'
        /bin/rm -f ./co-co
