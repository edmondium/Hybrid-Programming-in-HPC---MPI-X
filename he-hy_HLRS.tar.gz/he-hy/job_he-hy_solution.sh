#!/bin/bash

# Take care of correct placement both for MPI processes and OpenMP threads

#PBS -N he-hy_PIN
#PBS -l select=2:node_type=rome:mpiprocs=8:ompthreads=16
#PBS -l walltime=00:02:00
 
cd $PBS_O_WORKDIR

export OMP_NUM_THREADS=16

mpirun -np 16 omplace -nt 16 ./he-hy | sort -k 3 -k 8 -n
