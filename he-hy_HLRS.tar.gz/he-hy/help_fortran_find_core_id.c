/* ************************************************************************** */
/*                                                                            */
/* help_fortran_find_core_id.c (C source code).                               */
/*                                                                            */
/*      vsc4:  module load intel intel-mpi                                    */
/*      vsc4:  icc -c help_fortran_find_core_id.c                             */
/*                                                                            */
/*      usage within Fortran code:                                            */
/*                                                                            */
/*             integer :: core_id                                             */
/*             integer, external :: find_core_id                              */
/*             core_id = find_core_id()                                       */
/*                                                                            */
/* ************************************************************************** */

/* #include <sched.h> */
int sched_getcpu();

int find_core_id_ ()
{
    int core_id;
    core_id = sched_getcpu();
    return core_id;
}
