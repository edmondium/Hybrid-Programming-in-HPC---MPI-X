/* ************************************************************************** */
/*                                                                            */
/* Hybrid MPI+OpenMP "Hello world!" program (C source code).                  */
/*                                                                            */
/* - Reports core_id and node_name for all MPI processes and OpenMP threads.  */
/* - It does not use conditional compilation (for brevity and readability).   */
/*                                                                            */
/* - Course material: Hybrid Programming in HPC - MPI+X                       */
/*                                                                            */
/*                    It is made freely available with the understanding that */
/*                    every copy must include this header and that            */
/*                    the authors as well as VSC and TU Wien                  */
/*                    take no responsibility for the use of this program.     */
/*                                                                            */
/*        (c) 04/2022 Claudia Blaas-Schenner (VSC Research Center, TU Wien)   */
/*                    claudia.blaas-schenner@tuwien.ac.at                     */
/*                                                                            */
/*      vsc4:  module load intel intel-mpi                                    */
/*      vsc4:  mpiicc -qopenmp -o he-hy he-hy.c                               */
/*      vsc4:  export MPI_PROCESSES=4   [1-48 on one default node (48 cores)] */
/*      vsc4:  export OMP_NUM_THREADS=4 [1-48 on one default node (48 cores)] */
/*      vsc4:  export KMP_AFFINITY=granularity=thread,compact,1,0             */
/*      vsc4:  export I_MPI_PIN_DOMAIN=`expr 2 \* $OMP_NUM_THREADS`    [h.t.] */
/*      vsc4:  mpirun -n $MPI_PROCESSES ./he-hy | sort -n | cut -c 1-79       */
/*                                                                            */
/* ************************************************************************** */

/* #include <sched.h> */                            /* ... sched_getcpu() */
#include <mpi.h>                                    /* MPI header */
#include <omp.h>                                    /* OpenMP header */
#include <stdio.h>

int main(int argc, char *argv[])
{

int rank = 0,      size = 1;                        /* MPI - initialized */
int thread_id = 0, num_threads = 1;                 /* OpenMP - initialized */
int provided = 0;                                   /* MPI+OpenMP */
int core_id;                                        /* ... core_id */
int namelen;                                        /* ... MPI processor_name */
char name[MPI_MAX_PROCESSOR_NAME];                  /* ... MPI processor_name */

MPI_Init_thread(&argc, &argv, MPI_THREAD_FUNNELED, &provided);  /* MPI+OpenMP */

MPI_Comm_rank(MPI_COMM_WORLD, &rank);               /* MPI rank */
MPI_Comm_size(MPI_COMM_WORLD, &size);               /* MPI size */
MPI_Get_processor_name(name, &namelen);             /* ... MPI processor_name */

#pragma omp parallel private(thread_id,num_threads,core_id) /* OpenMP parallel*/
{
thread_id = omp_get_thread_num();                   /* OpenMP thread_id */
num_threads = omp_get_num_threads();                /* OpenMP num_threads */
core_id = sched_getcpu();                           /* ... core_id */

if (rank == 0 && thread_id == 0)
{
printf ("a: he-hy = Hybrid MPI+OpenMP program that reports core_id and node_name (c) cb\n");
printf ("b: all levels of MPI_THREAD_*: SINGLE=%d, FUNNELED=%d, SERIALIZED=%d, MULTIPLE=%d\n", MPI_THREAD_SINGLE, MPI_THREAD_FUNNELED, MPI_THREAD_SERIALIZED, MPI_THREAD_MULTIPLE);
printf ("c: level of thread support required = %d and provided = %d\n", MPI_THREAD_FUNNELED, provided);
printf ("d: Hello world! -Running with %4i MPI processes each with %4i OpenMP threads\n", size, num_threads);
}

printf ("MPI process %4i / %4i OpenMP thread %4i / %4i ON core %4i of node %s\n", rank, size, thread_id, num_threads, core_id, name);

}                                                   /* OpenMP parallel end */

MPI_Finalize();                                     /* MPI finalization */

}
