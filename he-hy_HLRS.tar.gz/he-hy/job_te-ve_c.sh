#!/bin/bash

#PBS -N te-ve_c
#PBS -l select=1:node_type=rome:mpiprocs=128
#PBS -l walltime=00:02:00
 
cd $PBS_O_WORKDIR

  echo '#############################'
  echo '# te-ve_c = test MPI library '
  echo '#############################'
  echo ''
  echo 'mpicc -o te-ve te-ve.c'
        mpicc -o te-ve te-ve.c
  echo 'mpirun -n 1 ./te-ve'
  echo '#############################'
        mpirun -n 1 ./te-ve
  echo '#############################'
        /bin/rm -f ./te-ve
