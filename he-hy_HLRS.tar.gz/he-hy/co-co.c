/* ************************************************************************** */
/*                                                                            */
/* Hybrid MPI+OpenMP "Hello world!" program (C source code).                  */
/*                                                                            */
/* - Demo for the use of conditional compilation.                             */
/*                                                                            */
/* - Course material: Hybrid Programming in HPC - MPI+X                       */
/*                                                                            */
/*                    It is made freely available with the understanding that */
/*                    every copy must include this header and that            */
/*                    the authors as well as VSC and TU Wien                  */
/*                    take no responsibility for the use of this program.     */
/*                                                                            */
/*        (c) 04/2022 Claudia Blaas-Schenner (VSC Research Center, TU Wien)   */
/*                    claudia.blaas-schenner@tuwien.ac.at                     */
/*                                                                            */
/*      vsc4:  module load intel intel-mpi                                    */
/*      vsc4:  export MPI_PROCESSES=4   [1-48 on one default node (48 cores)] */
/*      vsc4:  export OMP_NUM_THREADS=4 [1-48 on one default node (48 cores)] */
/*      vsc4:  MPI+OpenMP: mpiicc -DUSE_MPI -qopenmp -o co-co co-co.c         */
/*      vsc4:              mpirun -n $MPI_PROCESSES ./co-co | sort -n         */
/*      vsc4:  MPI:        mpiicc -DUSE_MPI -o co-co co-co.c                  */
/*      vsc4:              mpirun -n $MPI_PROCESSES ./co-co | sort -n         */
/*      vsc4:  OpenMP:     icc -qopenmp -o co-co co-co.c                      */
/*      vsc4:              ./co-co | sort -n                                  */
/*      vsc4:  serial:     icc -o co-co co-co.c                               */
/*      vsc4:              ./co-co | sort -n                                  */
/*                                                                            */
/* ************************************************************************** */

#ifdef USE_MPI
#       include <mpi.h>
#endif
#ifdef _OPENMP
#       include <omp.h>
#endif
#include <stdio.h>

int main(int argc, char *argv[])
{

int rank, size;
int thread_id, num_threads;
int provided = 0;

#ifdef USE_MPI
#ifdef _OPENMP
       MPI_Init_thread(&argc, &argv, MPI_THREAD_FUNNELED, &provided);
#else
       MPI_Init(&argc, &argv);
#endif
#endif

#ifdef USE_MPI
       MPI_Comm_rank(MPI_COMM_WORLD, &rank);
       MPI_Comm_size(MPI_COMM_WORLD, &size);
#else
       rank = 0;
       size = 1;
#endif

#ifdef _OPENMP
#      pragma omp parallel private(thread_id,num_threads)
       {
       thread_id = omp_get_thread_num();
       num_threads = omp_get_num_threads();
       /* } SEE BELOW: omp parallel end */
#else
       thread_id = 0;
       num_threads = 1;
#endif

/* ************************************************************************** */
if (rank == 0 && thread_id == 0)
{
printf ("a: Hello world! - size = %4i, num_threads = %4i\n", size, num_threads);

#ifdef USE_MPI
#ifdef _OPENMP
       printf ("b: This is: Hybrid MPI+OpenMP\n");
#else
       printf ("b: This is: pure MPI\n");
#endif
#else
#ifdef _OPENMP
       printf ("b: This is: pure OpenMP\n");
#else
       printf ("b: This is: serial\n");
#endif
#endif

}

printf ("rank / size %4i / %4i - thread_id / num_threads %4i / %4i\n", rank, size, thread_id, num_threads);
/* ************************************************************************** */

#ifdef _OPENMP
       } /* omp parallel end */
#endif

#ifdef USE_MPI
       MPI_Finalize();
#endif

}
