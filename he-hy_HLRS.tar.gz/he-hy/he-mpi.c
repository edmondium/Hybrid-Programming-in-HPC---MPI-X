/* ************************************************************************** */
/*                                                                            */
/* MPI "Hello world!" program (C source code).                                */
/*                                                                            */
/* - Reports core_id and node_name for all MPI processes.                     */
/* - It does not use conditional compilation (for brevity and readability).   */
/*                                                                            */
/* - Course material: Hybrid Programming in HPC - MPI+X                       */
/*                                                                            */
/*                    It is made freely available with the understanding that */
/*                    every copy must include this header and that            */
/*                    the authors as well as VSC and TU Wien                  */
/*                    take no responsibility for the use of this program.     */
/*                                                                            */
/*        (c) 04/2022 Claudia Blaas-Schenner (VSC Research Center, TU Wien)   */
/*                    claudia.blaas-schenner@tuwien.ac.at                     */
/*                                                                            */
/*      vsc4:  module load intel intel-mpi                                    */
/*      vsc4:  mpiicc -o he-mpi he-mpi.c                                      */
/*      vsc4:  export MPI_PROCESSES=16  [1-48 on one default node (48 cores)] */
/*      vsc4:  mpirun -n $MPI_PROCESSES ./he-mpi | sort -n | cut -c 1-53      */
/*                                                                            */
/* ************************************************************************** */

/* #include <sched.h> */                            /* ... sched_getcpu() */
#include <mpi.h>                                    /* MPI header */
#include <stdio.h>

int main(int argc, char *argv[])
{

int rank = 0,      size = 1;                        /* MPI - initialized */
int core_id;                                        /* ... core_id */
int namelen;                                        /* ... MPI processor_name */
char name[MPI_MAX_PROCESSOR_NAME];                  /* ... MPI processor_name */

MPI_Init(&argc, &argv);                             /* MPI initialization */

MPI_Comm_rank(MPI_COMM_WORLD, &rank);               /* MPI rank */
MPI_Comm_size(MPI_COMM_WORLD, &size);               /* MPI size */

MPI_Get_processor_name(name, &namelen);             /* ... MPI processor_name */
core_id = sched_getcpu();                           /* ... core_id */

if (rank == 0)
{
printf ("he-mpi = MPI program prints core_id & node_name (cb)\n");
printf ("Hello world! -Running with %4i MPI processes\n", size);
}

printf ("MPI process %4i / %4i ON core %4i of node %s\n", rank, size, core_id, name);

MPI_Finalize();                                     /* MPI finalization */

}
