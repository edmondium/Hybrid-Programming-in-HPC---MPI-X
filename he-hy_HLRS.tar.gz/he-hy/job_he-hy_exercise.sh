#!/bin/bash

# Take care of correct placement both for MPI processes and OpenMP threads

#PBS -N he-hy_WRONG
#PBS -l select=2:node_type=rome:mpiprocs=128
#PBS -l walltime=00:02:00
 
cd $PBS_O_WORKDIR

export OMP_NUM_THREADS=16

mpirun -n 16 ./he-hy | sort -k 3 -k 8 -n
