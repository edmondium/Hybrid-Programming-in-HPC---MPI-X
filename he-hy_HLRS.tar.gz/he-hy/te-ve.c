/* ************************************************************************** */
/*                                                                            */
/* Test MPI library for version and language support (C source code).         */
/*                                                                            */
/* - Course material: Hybrid Programming in HPC - MPI+X                       */
/*                                                                            */
/*                    It is made freely available with the understanding that */
/*                    every copy must include this header and that            */
/*                    the authors as well as HLRS, VSC, and TU Wien           */
/*                    take no responsibility for the use of this program.     */
/*                                                                            */
/*        (c) 04/2022 Claudia Blaas-Schenner (VSC Research Center, TU Wien)   */
/*                    claudia.blaas-schenner@tuwien.ac.at                     */
/*                                                                            */
/*      vsc4:  module load intel intel-mpi                                    */
/*      vsc4:  mpiicc -o te-ve te-ve.c                                        */
/*      vsc4:  mpirun -n 1 ./te-ve                                            */
/*                                                                            */
/* ************************************************************************** */

#include <mpi.h>
#include <stdio.h>

int main (int argc, char *argv[])
{
int rank;
int lib_version, lib_subversion;
MPI_Errhandler errhandler;

MPI_Init(&argc, &argv);
MPI_Comm_rank(MPI_COMM_WORLD, &rank);
if (rank == 0)
{
   printf ("\n");
   printf ("* MPI VERSION:\n");
   MPI_Get_version(&lib_version, &lib_subversion);
   printf ("  Version: Library: %d.%d\n", lib_version, lib_subversion);
   printf ("  Version: mpi.h:   %d.%d\n", MPI_VERSION, MPI_SUBVERSION);
   printf ("\n");
   printf ("* MPI ERROR HANDLING:\n");
   MPI_Comm_get_errhandler(MPI_COMM_WORLD, &errhandler);
if (errhandler == MPI_ERRORS_ARE_FATAL)
{
   printf ("  default MPI communication is with MPI_ERRORS_ARE_FATAL\n");
}
if (errhandler != MPI_ERRORS_ARE_FATAL)
{
   printf ("  non-default setting for the errhandler for MPI communication:\n");
   printf ("  MPI_Comm_get_errhandler(MPI_COMM_WORLD, errhandler) -> %d\n", errhandler);
   printf ("                                  MPI_ERRORS_RETURN    = %d\n", MPI_ERRORS_RETURN);
   printf ("                                  MPI_ERRORS_ARE_FATAL = %d\n", MPI_ERRORS_ARE_FATAL);
}
   MPI_File_get_errhandler(MPI_FILE_NULL, &errhandler);
if (errhandler == MPI_ERRORS_RETURN)
{
   printf ("  default MPI-I/O is with MPI_ERRORS_RETURN\n");
}
if (errhandler != MPI_ERRORS_RETURN)
{
   printf ("  non-default setting for the errhandler for MPI-I/O:\n");
   printf ("  MPI_File_get_errhandler(MPI_FILE_NULL, errhandler)  -> %d\n", errhandler);
   printf ("                                  MPI_ERRORS_ARE_FATAL = %d\n", MPI_ERRORS_ARE_FATAL);
   printf ("                                  MPI_ERRORS_RETURN    = %d\n", MPI_ERRORS_RETURN);
}
   printf ("\n");
}
MPI_Finalize();
}
