#!/bin/bash

#PBS -N te-ve_f
#PBS -l select=1:node_type=rome:mpiprocs=128
#PBS -l walltime=00:02:00
 
cd $PBS_O_WORKDIR

  echo '####################################################'
  echo '### te-ve_f = test MPI library: ####################'
  echo '####################################################'
  echo ''
  echo '### Fortran: mpi_f08 (new) module'
  echo ''
  echo 'mpif08 -o te-ve te-ve-mpi_f08.f90'
        mpif08 -o te-ve te-ve-mpi_f08.f90
  echo 'mpirun -n 1 ./te-ve'
  echo '####################################################'
        mpirun -n 1 ./te-ve
  echo '####################################################'
  echo ''
  echo '### Fortran: mpi (old) module'
  echo ''
  echo 'mpif90 -o te-ve te-ve-mpi_old.f90'
        mpif90 -o te-ve te-ve-mpi_old.f90
  echo 'mpirun -n 1 ./te-ve'
  echo '####################################################'
        mpirun -n 1 ./te-ve
  echo '####################################################'
  echo ''
  echo '####################################################'
  echo '### CHECK keyword based argument lists for mpi (old)'
  echo '### if compilation fails (see below):'
  echo '###             -> NO keyword based argument lists'
  echo '###             -> (output below can be ignored)'
  echo '####################################################'
  echo ''
  echo 'mpif90 -o te-ve te-ve-mpi_old-key.f90'
        mpif90 -o te-ve te-ve-mpi_old-key.f90
  echo 'mpirun -n 1 ./te-ve | tail -8'
  echo '####################################################'
        mpirun -n 1 ./te-ve | tail -8
  echo '####################################################'
        /bin/rm -f ./te-ve
