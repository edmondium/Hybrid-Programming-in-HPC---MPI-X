#!/bin/bash

#PBS -N co-co_f
#PBS -l select=1:node_type=rome:mpiprocs=128
#PBS -l walltime=00:02:00
 
cd $PBS_O_WORKDIR

  export MPI_PROCESSES=4
  export OMP_NUM_THREADS=4

  echo '##########################################'
  echo '# co-co = Demo for CONDITIONAL COMPILATION'
  echo '#         MPI_PROCESSES='$MPI_PROCESSES
  echo '#         OMP_NUM_THREADS='$OMP_NUM_THREADS
  echo '##########################################'
  echo '### CHECK COMPILER VERSION: ##############'
  echo 'mpif08 --version'
        mpif08 --version
  echo 'gfortran --version'
        gfortran --version
  echo '### MPI+OpenMP: ##########################'
  echo 'mpif08 -cpp -DUSE_MPI -fopenmp -o co-co co-co.f90'
        mpif08 -cpp -DUSE_MPI -fopenmp -o co-co co-co.f90
  echo 'mpirun -n $MPI_PROCESSES ./co-co | sort -n'
        mpirun -n $MPI_PROCESSES ./co-co | sort -n
  echo '### MPI: #################################'
  echo 'mpif08 -cpp -DUSE_MPI -o co-co co-co.f90'
        mpif08 -cpp -DUSE_MPI -o co-co co-co.f90
  echo 'mpirun -n $MPI_PROCESSES ./co-co | sort -n'
        mpirun -n $MPI_PROCESSES ./co-co | sort -n
  echo '### OpenMP: ##############################'
  echo 'gfortran -cpp -fopenmp -o co-co co-co.f90'
        gfortran -cpp -fopenmp -o co-co co-co.f90
  echo './co-co | sort -n'
        ./co-co | sort -n
  echo '### serial: ##############################'
  echo 'gfortran -cpp -o co-co co-co.f90'
        gfortran -cpp -o co-co co-co.f90
  echo './co-co | sort -n'
        ./co-co | sort -n
  echo '##########################################'
        /bin/rm -f ./co-co
