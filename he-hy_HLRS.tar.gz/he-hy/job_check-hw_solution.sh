#!/bin/bash

#PBS -N check-hw
#PBS -l select=1:node_type=rome:mpiprocs=128
#PBS -l walltime=00:02:00
 
cd $PBS_O_WORKDIR

################################################################################
# TODO:                                             #    _____     ____
# - Find out about the hardware of compute nodes:   #   |_   _|__ |  _ \  ___
#   How to - Get to know the hardware! e.g.:        #     | |/ _ \| | | |/ _ \
#   - likwid-topology -c      # +module for likwid  #     | | (_) | |_| | (_) |
#   - cpuinfo -A              # +module for intel   #     |_|\___/|____/ \___/
#   - numactl --hardware      #  standard Linux     #
################################################################################

  echo '##############################'
  echo 'Get to know the hardware!'
  echo '##############################'
  echo ''

  echo '##############################'
  echo 'likwid-topology -c'
  echo '##############################'

  module load likwid
  likwid-topology -c
  module unload likwid

# echo '##############################'
# echo 'cpuinfo -A'
# echo '##############################'
#
# module load intel
# cpuinfo -A
# module unload intel

  echo '##############################'
  echo 'numactl --hardware'
  echo '##############################'

  numactl --hardware

  echo '##############################'
