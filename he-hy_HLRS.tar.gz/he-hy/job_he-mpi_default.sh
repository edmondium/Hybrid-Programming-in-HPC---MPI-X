#!/bin/bash

#PBS -N he-mpi_default
#PBS -l select=2:node_type=rome:mpiprocs=128
#PBS -l walltime=00:02:00
 
cd $PBS_O_WORKDIR

mpirun -n 256 ./he-mpi | sort -k 3 -n
