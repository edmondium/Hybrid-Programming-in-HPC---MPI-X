#!/bin/bash

#PBS -N env
#PBS -l select=1:node_type=rome:mpiprocs=128
#PBS -l walltime=00:02:00
 
cd $PBS_O_WORKDIR

echo '##############################'
echo 'HOSTNAME='$HOSTNAME
echo '##############################'
echo '### ALL ENVIRONMENT VARIABLES:'
echo ''
env
echo ''
echo '##############################'
