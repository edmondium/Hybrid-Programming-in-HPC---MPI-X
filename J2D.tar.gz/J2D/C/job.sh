#!/bin/bash

#PBS -N heat
#PBS -l select=1:node_type=rome:mpiprocs=128
#PBS -l walltime=00:10:00
 
cd $PBS_O_WORKDIR

mpirun -n 128 omplace -c 0-127 ./heat 100 100 1000
